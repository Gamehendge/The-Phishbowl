thaumcraft-api
==============

Thaumcraft Api



This is just to create an easy to access place for the api code. 

I will still place the zips on the minecraft forum post for the "official" version of the api - the code here will usually be for dev versions.
