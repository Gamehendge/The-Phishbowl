package thaumcraft.api.nodes;

public enum NodeModifier
{
    BRIGHT, PALE, FADING
}