@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|tools")
package buildcraft.api.tools;
import cpw.mods.fml.common.API;