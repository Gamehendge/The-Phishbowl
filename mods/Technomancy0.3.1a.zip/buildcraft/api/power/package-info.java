@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|power")
package buildcraft.api.power;
import cpw.mods.fml.common.API;