@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|recipes")
package buildcraft.api.recipes;
import cpw.mods.fml.common.API;