@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|inventory")
package buildcraft.api.inventory;
import cpw.mods.fml.common.API;