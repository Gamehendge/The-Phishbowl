@API(apiVersion="1.0",owner="BuildCraft|Core",provides="BuildCraftAPI|core")
package buildcraft.api.core;
import cpw.mods.fml.common.API;