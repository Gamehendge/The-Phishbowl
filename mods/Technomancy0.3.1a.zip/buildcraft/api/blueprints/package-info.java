@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|blueprints")
package buildcraft.api.blueprints;
import cpw.mods.fml.common.API;