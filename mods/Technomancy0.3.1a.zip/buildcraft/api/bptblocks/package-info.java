@API(apiVersion="1.0",owner="BuildCraftAPI|blueprints",provides="BuildCraftAPI|bptblocks")
package buildcraft.api.bptblocks;
import cpw.mods.fml.common.API;