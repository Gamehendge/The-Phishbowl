@API(apiVersion="1.0",owner="BuildCraftAPI|core",provides="BuildCraftAPI|gates")
package buildcraft.api.gates;
import cpw.mods.fml.common.API;