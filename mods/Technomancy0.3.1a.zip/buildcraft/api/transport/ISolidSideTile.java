package buildcraft.api.transport;

import net.minecraftforge.common.ForgeDirection;

public interface ISolidSideTile {
	public boolean isSolidOnSide(ForgeDirection side);
}
