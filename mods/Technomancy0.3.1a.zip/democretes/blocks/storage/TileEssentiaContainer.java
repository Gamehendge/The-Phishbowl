package democretes.blocks.storage;

import democretes.blocks.TileTechnomancy;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.ForgeDirection;
import thaumcraft.api.ThaumcraftApiHelper;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.aspects.IAspectSource;
import thaumcraft.api.aspects.IEssentiaTransport;
import thaumcraft.common.tiles.TileJarFillable;

public class TileEssentiaContainer extends TileTechnomancy implements IAspectSource, IEssentiaTransport{

	public Aspect aspectFilter = null;
	public int amount;
	public int maxAmount = 640;
	public Aspect aspect = null;
	public int facing = 2;
	public int lid = 0;
	
	@Override
	public void readCustomNBT(NBTTagCompound compound)  {
		this.aspect = Aspect.getAspect(compound.getString("Aspect"));
		this.aspectFilter = Aspect.getAspect(compound.getString("AspectFilter"));
		this.amount = compound.getShort("Amount");
		this.facing = compound.getByte("facing");
	}
	
	@Override
	public void writeCustomNBT(NBTTagCompound compound)  {
		if (this.aspect != null) {
			compound.setString("Aspect", this.aspect.getTag());
		}
		if (this.aspectFilter != null) {
			compound.setString("AspectFilter", this.aspectFilter.getTag());
		}
		compound.setShort("Amount", (short)this.amount);
		compound.setByte("facing", (byte)this.facing);
	}
	
	int count = 0;
	public void updateEntity()	  {
	   super.updateEntity();
	   if ((!this.worldObj.isRemote) && (++this.count % 10 == 0) && (this.amount < this.maxAmount)) {
	     fillJar();
	   }
	}
	
	void fillJar()	  {
	    TileEntity te = ThaumcraftApiHelper.getConnectableTile(this.worldObj, this.xCoord, this.yCoord, this.zCoord, ForgeDirection.UP);
	    if (te != null)	    {
	      IEssentiaTransport ic = (IEssentiaTransport)te;
	      if (!ic.canOutputTo(ForgeDirection.DOWN)) {
	        return;
	      }
	      Aspect ta = null;
	      if (this.aspectFilter != null) {
	        ta = this.aspectFilter;
	      } else if ((this.aspect != null) && (this.amount > 0)) {
	        ta = this.aspect;
	      } else if ((ic.getEssentiaAmount(ForgeDirection.DOWN) > 0) && 
	        (ic.getSuctionAmount(ForgeDirection.DOWN) < getSuctionAmount(ForgeDirection.UP)) && (getSuctionAmount(ForgeDirection.UP) >= ic.getMinimumSuction())) {
	        ta = ic.getEssentiaType(ForgeDirection.DOWN);
	      }
	      if ((ta != null) && (ic.getSuctionAmount(ForgeDirection.DOWN) < getSuctionAmount(ForgeDirection.UP))) {
	        addToContainer(ta, ic.takeVis(ta, 1));
	      }
	    }
	  }
	 
	@Override
	public AspectList getAspects()  {
	    AspectList al = new AspectList();
	    if ((this.aspect != null) && (this.amount > 0)) {
	      al.add(this.aspect, this.amount);
	    }
	    return al;
	}	  

	@Override
	public int addToContainer(Aspect tag, int amount)  {
	  if (amount == 0) {
	    return amount;
	  }
	  if (((this.amount < this.maxAmount) && (tag == this.aspect)) || (this.amount == 0)) {
	    this.aspect = tag;
	    int added = Math.min(amount, this.maxAmount - this.amount);
	    this.amount += added;
	    amount -= added;
	  }
	  this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
	  return amount;
	}
	  
	@Override
	public boolean takeFromContainer(Aspect tag, int amount)  {
	  if ((this.amount >= amount) && (tag == this.aspect)) {
	    this.amount -= amount;
	    if (this.amount <= 0) {
	      this.aspect = null;
	      this.amount = 0;
	    }
	    this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
	    return true;
	  }
	  return false;
	}
	
	@Override
	public boolean doesContainerContainAmount(Aspect tag, int amt) {
		if ((this.amount >= amt) && (tag == this.aspect)) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean doesContainerContain(AspectList ot)  {
		for (Aspect tt : ot.getAspects()) {
			if ((this.amount > 0) && (tt == this.aspect)) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int getMinimumSuction() {
	  return this.aspectFilter != null ? 56 + (amount/100) : 48 + (amount/100);
	}
	
	@Override
	public int takeVis(Aspect aspect, int amount) {
	  return takeFromContainer(aspect, amount) ? amount : 0;
	}
	
	@Override
	public void setAspects(AspectList aspects) {}

	@Override
	public boolean canUpdate()  {
	    return true;
	  }	
	
	@Override
	public boolean takeFromContainer(AspectList ot) {
	  return false;
	}	
	
	@Override
	public boolean renderExtendedTube() {
	  return true;
	}	
	
	@Override
	public int containerContains(Aspect tag)  {
	  return 0;
	}
	
	@Override
	public boolean doesContainerAccept(Aspect tag) {
	  return this.aspectFilter != null ? tag.equals(this.aspectFilter) : true;
	}
	
	@Override
	public boolean isConnectable(ForgeDirection face) {
	  return face == ForgeDirection.UP;
	}
	
	@Override
	public boolean canInputFrom(ForgeDirection face) {
	  return face == ForgeDirection.UP;
	}
	
	@Override
	public boolean canOutputTo(ForgeDirection face) {
	  return face == ForgeDirection.UP;
	}

	@Override
	public Aspect getSuctionType(ForgeDirection face) {
		return this.aspectFilter != null ? this.aspectFilter : this.aspect;
	}

	@Override
	public int getSuctionAmount(ForgeDirection loc) {
		if (this.amount < this.maxAmount){
			if (this.aspectFilter != null) {
				return 56 + (amount/100);
			}
			return 48 + (amount/100);
		}
		return 0;
	}

	@Override
	public int addVis(Aspect aspect, int amount) {
		return amount - addToContainer(aspect, amount);
	}

	@Override
	public Aspect getEssentiaType(ForgeDirection face) {
		return this.aspect;
	}

	@Override
	public int getEssentiaAmount(ForgeDirection face) {
		return this.amount;
	}

	@Override
	public void setSuction(Aspect aspect, int amount) {	}
	
}