package democretes.proxies;

import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import thaumcraft.client.fx.FXEssentiaTrail;

public class CommonProxy {

    public void initSounds() {

    }

    public void initRenderers() {

    }
    
    public void essentiaTrail(World world, double x, double y, double z, double tx, double ty, double tz, int color) {
    }

}
