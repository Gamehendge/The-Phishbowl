package democretes.handlers;

public class EventHandlerEntity {

}
