package democretes.lib;

public class ItemIds {

    // Defaults
    public static int idESSENTIA_CANNON_DEFAULT = 18000;
    public static int idITEM_MATERIAL_DEFAULT = 18001;
    public static int idITEM_PEN_DEFAULT = 18002;
    public static int idITEM_WAND_CORES_DEFAULT = 18003;
    public static int idITEM_FUSION_FOCUS_DEFAULT = 18004;
    
    public static int idESSENTIA_CANNON;
	public static int idITEM_MATERIAL;
	public static int idITEM_PEN;
	public static int idITEM_WAND_CORES;
	public static int idITEM_FUSION_FOCUS;

}
