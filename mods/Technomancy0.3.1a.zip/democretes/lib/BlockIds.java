package democretes.lib;

public class BlockIds {
	
	//Defaults
	public static int idNODE_DYNAMO_DEFAULT = 3998;
	public static int idESSENTIA_DYNAMO_DEFAULT = 3999;
	public static int idESSENTIA_CONTAINER_DEFAULT = 3400;
	public static int idCOSMETIC_OPAQUE_DEFAULT = 3410;
	public static int idCOSMETIC_PANE_DEFAULT = 3411;
	public static int idBIOME_MORPHER_DEFAULT = 3412;
	public static int idNODE_GENERATOR_DEFAULT = 3413;
	public static int idFLUX_LAMP_DEFAULT = 3414;
	public static int idTESLA_COIL_DEFALULT = 3415;
	public static int idELECTRIC_BELLOWS_DEFAULT = 3416;
	
	//Initializers
	public static int idNODE_DYNAMO;
	public static int idESSENTIA_CONTAINER;
	public static int idCOSMETIC_OPAQUE;
	public static int idCOSMETIC_PANE;
	public static int idESSENTIA_DYNAMO;
	public static int idBIOME_MORPHER;
	public static int idNODE_GENERATOR;
	public static int idFLUX_LAMP;
	public static int idTESLA_COIL;
	public static int idELECTRIC_BELLOWS;


}
