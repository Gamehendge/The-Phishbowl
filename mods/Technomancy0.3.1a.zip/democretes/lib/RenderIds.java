package democretes.lib;

public class RenderIds {

	public static int idEssentiaContainer;
	public static int idEssentiaDynamo;
	public static int idNodeDynamo;
	public static int idBiomeMorpher;
	public static int idNodeGenerator;
	public static int idFluxLamp;
	public static int idTeslaCoil;
	public static int idElectricBellows;
	

}
